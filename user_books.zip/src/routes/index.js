// const router = require('express').Router()
// const apiRoute = require('./api/app')
// const adminRoute = require('./admin/admin')
// router.use('/api', apiRoute)
//
// router.use('/admin', adminRoute)
// module.exports = router



module.exports = {
    apiUserRoutes: require('./api/app')
}