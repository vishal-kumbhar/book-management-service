const router = require('express').Router()
const { apiTokenAuth } = require('../../middlewares/api')

const AuthController = require('../../controller/api/AuthController')
const BookController = require('../../controller/api/BookController')


router.post('/login', AuthController.login)
router.post('/register', AuthController.signUp)
router.post('/change-password',apiTokenAuth,AuthController.changePassword)

router.post('/add-book',apiTokenAuth, BookController.AddBook)
router.get('/book-list',apiTokenAuth, BookController.BookList)
router.get('/user-book-list',apiTokenAuth, BookController.UserBookList)



module.exports = router